package company;

public class Main {

    public static void main(String[] args) {
        Iphone10 ObjectA = new Iphone10(1, Color.BLACK, "Instagram", "64-ГБ", new Model(2017, "Iphone10"));


        System.out.println(""Objeсt);
        ObjectA.Buy("50$");

    }
    Iphone11pro ObjectB = new Iphone11pro(2,"")

}
