package company;

public enum Color {
    BLACK,
    GREY,
    RED
}
